#!/usr/bin/with-contenv bashio

export DEVICE_IP=$(bashio::config 'device_ip')
export DEVICE_PORT=$(bashio::config 'device_port')
export USERNAME=$(bashio::config 'username')
export PASSWORD=$(bashio::config 'password')
export RC4_KEY=$(bashio::config 'rc4_key')
export TOKEN_REFRESH=$(bashio::config 'token_refresh_interval')
export SNAPSHOT_INTERVAL=$(bashio::config 'snapshot_interval')
export RTSP_STREAM=$(bashio::config 'rtsp_stream')
export LOG_RETENTION=$(bashio::config 'log_retention_days')

bashio::log.info "Starting Doordeer Smart Intercom Addon..."
bashio::log.info "Connecting to device at ${DEVICE_IP}:${DEVICE_PORT}"

cd /app
python3 -m doordeer_integration.main
