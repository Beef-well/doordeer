"""Doordeer Camera entity — RTSP stream + JPEG snapshot."""
from __future__ import annotations

import logging

from homeassistant.components.camera import Camera, CameraEntityFeature
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from . import DOMAIN, ADDON_BASE_URL

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    data = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([DoordeerCamera(data["session"], entry)])


class DoordeerCamera(Camera):
    """Doordeer video intercom camera."""

    _attr_has_entity_name = True
    _attr_name = "Doorbell Camera"
    _attr_icon = "mdi:doorbell-video"
    _attr_supported_features = CameraEntityFeature.STREAM

    def __init__(self, session, entry: ConfigEntry) -> None:
        super().__init__()
        self._session = session
        self._entry = entry
        self._attr_unique_id = f"{DOMAIN}_{entry.entry_id}_camera"
        self._rtsp_url: str | None = None

    @property
    def device_info(self):
        return {
            "identifiers": {(DOMAIN, self._entry.entry_id)},
            "name": "Doordeer Intercom",
            "manufacturer": "doordeer smart Inc",
            "model": "Video Intercom",
        }

    async def async_camera_image(
        self, width: int | None = None, height: int | None = None
    ) -> bytes | None:
        """Return cached snapshot bytes from addon."""
        try:
            async with self._session.get(f"{ADDON_BASE_URL}/api/snapshot") as resp:
                if resp.status == 200:
                    return await resp.read()
        except Exception as exc:
            _LOGGER.error("Doordeer: snapshot fetch error: %s", exc)
        return None

    async def stream_source(self) -> str | None:
        """Return RTSP URL for HA stream integration."""
        if self._rtsp_url is None:
            await self._fetch_rtsp()
        return self._rtsp_url

    async def _fetch_rtsp(self) -> None:
        try:
            async with self._session.get(f"{ADDON_BASE_URL}/api/rtsp") as resp:
                if resp.status == 200:
                    data = await resp.json()
                    self._rtsp_url = data.get("mainvideo")
                    _LOGGER.info("Doordeer: RTSP URL loaded: %s", self._rtsp_url)
        except Exception as exc:
            _LOGGER.error("Doordeer: RTSP fetch error: %s", exc)
