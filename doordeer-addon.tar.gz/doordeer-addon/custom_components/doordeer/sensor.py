"""Doordeer Sensor entities — connection status, log count, RTSP info."""
from __future__ import annotations

import logging
from datetime import timedelta

from homeassistant.components.sensor import SensorEntity, SensorStateClass
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import (
    CoordinatorEntity,
    DataUpdateCoordinator,
)

from . import DOMAIN, ADDON_BASE_URL

_LOGGER = logging.getLogger(__name__)
SCAN_INTERVAL = timedelta(seconds=30)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    data = hass.data[DOMAIN][entry.entry_id]
    session = data["session"]

    coordinator = DataUpdateCoordinator(
        hass,
        _LOGGER,
        name="doordeer_status",
        update_method=lambda: _fetch_status(session),
        update_interval=SCAN_INTERVAL,
    )
    await coordinator.async_config_entry_first_refresh()

    async_add_entities([
        DoordeerConnectionSensor(coordinator, entry),
        DoordeerLogCountSensor(coordinator, session, entry),
        DoordeerRtspSensor(coordinator, entry),
    ])


async def _fetch_status(session) -> dict:
    try:
        async with session.get(f"{ADDON_BASE_URL}/api/status") as resp:
            return await resp.json()
    except Exception as exc:
        _LOGGER.error("Doordeer: status fetch error: %s", exc)
        return {}


class DoordeerConnectionSensor(CoordinatorEntity, SensorEntity):
    """Shows connected/disconnected state."""

    _attr_has_entity_name = True
    _attr_name = "Connection Status"
    _attr_icon = "mdi:lan-connect"

    def __init__(self, coordinator, entry):
        super().__init__(coordinator)
        self._entry = entry
        self._attr_unique_id = f"{DOMAIN}_{entry.entry_id}_connection"

    @property
    def device_info(self):
        return {
            "identifiers": {(DOMAIN, self._entry.entry_id)},
            "name": "Doordeer Intercom",
            "manufacturer": "doordeer smart Inc",
            "model": "Video Intercom",
        }

    @property
    def native_value(self):
        data = self.coordinator.data or {}
        return "connected" if data.get("connected") else "disconnected"

    @property
    def extra_state_attributes(self):
        data = self.coordinator.data or {}
        return {
            "token_present": data.get("token_present"),
            "server_time": data.get("server_time"),
        }


class DoordeerLogCountSensor(CoordinatorEntity, SensorEntity):
    """Shows total access log entries."""

    _attr_has_entity_name = True
    _attr_name = "Access Log Entries"
    _attr_icon = "mdi:clipboard-list"
    _attr_state_class = SensorStateClass.TOTAL_INCREASING

    def __init__(self, coordinator, session, entry):
        super().__init__(coordinator)
        self._session = session
        self._entry = entry
        self._attr_unique_id = f"{DOMAIN}_{entry.entry_id}_log_count"
        self._count = 0

    @property
    def device_info(self):
        return {
            "identifiers": {(DOMAIN, self._entry.entry_id)},
            "name": "Doordeer Intercom",
        }

    @property
    def native_value(self):
        return self._count

    async def async_update(self) -> None:
        try:
            async with self._session.get(f"{ADDON_BASE_URL}/api/log?limit=1000") as resp:
                data = await resp.json()
                self._count = len(data.get("log", []))
        except Exception:
            pass


class DoordeerRtspSensor(CoordinatorEntity, SensorEntity):
    """Shows the RTSP main stream URL."""

    _attr_has_entity_name = True
    _attr_name = "RTSP Stream URL"
    _attr_icon = "mdi:video-wireless"

    def __init__(self, coordinator, entry):
        super().__init__(coordinator)
        self._entry = entry
        self._attr_unique_id = f"{DOMAIN}_{entry.entry_id}_rtsp"

    @property
    def device_info(self):
        return {
            "identifiers": {(DOMAIN, self._entry.entry_id)},
            "name": "Doordeer Intercom",
        }

    @property
    def native_value(self):
        data = self.coordinator.data or {}
        return data.get("rtsp_main", "unavailable")

    @property
    def extra_state_attributes(self):
        data = self.coordinator.data or {}
        return {
            "rtsp_sub": data.get("rtsp_sub"),
            "video_format": data.get("video_format"),
            "audio_format": data.get("audio_format"),
        }
