"""Config flow for Doordeer integration."""
from __future__ import annotations

import voluptuous as vol
from homeassistant import config_entries
from homeassistant.core import HomeAssistant

from . import DOMAIN

DATA_SCHEMA = vol.Schema({
    vol.Required("device_ip"): str,
    vol.Optional("device_port", default=3800): int,
    vol.Optional("username", default="admin"): str,
    vol.Optional("password", default="admin"): str,
})


class DoordeerConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):
    """Handle a config flow for Doordeer."""

    VERSION = 1

    async def async_step_user(self, user_input=None):
        errors = {}
        if user_input is not None:
            return self.async_create_entry(
                title=f"Doordeer @ {user_input['device_ip']}",
                data=user_input,
            )
        return self.async_show_form(
            step_id="user",
            data_schema=DATA_SCHEMA,
            errors=errors,
        )
