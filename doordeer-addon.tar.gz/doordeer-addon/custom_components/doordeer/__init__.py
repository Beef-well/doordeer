"""Doordeer Smart Intercom — Home Assistant Custom Component."""
from __future__ import annotations

import logging
from typing import Any

import aiohttp
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import Platform
from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession

_LOGGER = logging.getLogger(__name__)

DOMAIN = "doordeer"
ADDON_BASE_URL = "http://localhost:8099"

PLATFORMS = [
    Platform.LOCK,
    Platform.CAMERA,
    Platform.BUTTON,
    Platform.SENSOR,
    Platform.EVENT,
]


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up Doordeer from a config entry."""
    session = async_get_clientsession(hass)
    hass.data.setdefault(DOMAIN, {})
    hass.data[DOMAIN][entry.entry_id] = {
        "session": session,
        "addon_url": ADDON_BASE_URL,
    }

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)

    # Register services
    async def handle_unlock(call: Any) -> None:
        async with session.post(f"{ADDON_BASE_URL}/api/unlock") as resp:
            result = await resp.json()
            _LOGGER.info("Doordeer unlock service result: %s", result)

    async def handle_change_password(call: Any) -> None:
        payload = {
            "password": call.data.get("password"),
            "username": call.data.get("username"),
        }
        async with session.post(f"{ADDON_BASE_URL}/api/password", json=payload) as resp:
            result = await resp.json()
            _LOGGER.info("Doordeer change_password result: %s", result)

    hass.services.async_register(DOMAIN, "unlock", handle_unlock)
    hass.services.async_register(DOMAIN, "change_password", handle_change_password)

    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a config entry."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unload_ok:
        hass.data[DOMAIN].pop(entry.entry_id)
    return unload_ok
