"""Doordeer Button entity — one-tap unlock."""
from __future__ import annotations

import logging

from homeassistant.components.button import ButtonEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from . import DOMAIN, ADDON_BASE_URL

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    data = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([DoordeerUnlockButton(data["session"], entry)])


class DoordeerUnlockButton(ButtonEntity):
    """One-tap door unlock button."""

    _attr_has_entity_name = True
    _attr_name = "Unlock Door"
    _attr_icon = "mdi:door-open"

    def __init__(self, session, entry: ConfigEntry) -> None:
        self._session = session
        self._entry = entry
        self._attr_unique_id = f"{DOMAIN}_{entry.entry_id}_unlock_button"

    @property
    def device_info(self):
        return {
            "identifiers": {(DOMAIN, self._entry.entry_id)},
            "name": "Doordeer Intercom",
            "manufacturer": "doordeer smart Inc",
            "model": "Video Intercom",
        }

    async def async_press(self) -> None:
        async with self._session.post(f"{ADDON_BASE_URL}/api/unlock") as resp:
            result = await resp.json()
            _LOGGER.info("Doordeer: unlock button pressed, result: %s", result)
