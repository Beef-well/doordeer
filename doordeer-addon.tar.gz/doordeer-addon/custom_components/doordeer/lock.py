"""Doordeer Lock entity — exposes door as a HA lock."""
from __future__ import annotations

import logging
from typing import Any

from homeassistant.components.lock import LockEntity, LockEntityFeature
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from . import DOMAIN, ADDON_BASE_URL

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    data = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([DoordeerLock(data["session"], entry)])


class DoordeerLock(LockEntity):
    """Represents the doordeer door lock."""

    _attr_has_entity_name = True
    _attr_name = "Door Lock"
    _attr_icon = "mdi:door-closed-lock"
    # Lock is always "locked" by default — it's a momentary unlock
    _attr_is_locked = True

    def __init__(self, session, entry: ConfigEntry) -> None:
        self._session = session
        self._entry = entry
        self._attr_unique_id = f"{DOMAIN}_{entry.entry_id}_lock"

    @property
    def device_info(self):
        return {
            "identifiers": {(DOMAIN, self._entry.entry_id)},
            "name": "Doordeer Intercom",
            "manufacturer": "doordeer smart Inc",
            "model": "Video Intercom",
        }

    async def async_unlock(self, **kwargs: Any) -> None:
        """Send unlock command to addon API."""
        async with self._session.post(f"{ADDON_BASE_URL}/api/unlock") as resp:
            result = await resp.json()
            if result.get("success"):
                _LOGGER.info("Doordeer: door unlocked via HA lock entity")
            else:
                _LOGGER.warning("Doordeer: unlock failed: %s", result)

    async def async_lock(self, **kwargs: Any) -> None:
        """Door re-locks automatically — nothing to send."""
        _LOGGER.debug("Doordeer: lock is auto-relocking (hardware controlled)")
