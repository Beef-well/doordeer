"""
Doordeer Addon — Main entry point.
Runs an aiohttp web server that:
  - Bridges Home Assistant to the doordeer LAN API
  - Serves the ingress panel UI
  - Exposes REST endpoints for HA custom component
  - Maintains token refresh and log pruning background tasks
"""
import asyncio
import json
import logging
import os
import time
from pathlib import Path

from aiohttp import web

from .client import DoordeerClient, DoordeerConfig

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
_LOGGER = logging.getLogger("doordeer.main")

# ---------------------------------------------------------------------------
# Config from environment (set by run.sh from addon options)
# ---------------------------------------------------------------------------

def get_config() -> DoordeerConfig:
    return DoordeerConfig(
        device_ip=os.environ["DEVICE_IP"],
        device_port=int(os.environ.get("DEVICE_PORT", 3800)),
        username=os.environ.get("USERNAME", "admin"),
        password=os.environ.get("PASSWORD", "admin"),
        rc4_key=os.environ.get("RC4_KEY", ""),
    )


# ---------------------------------------------------------------------------
# Route handlers
# ---------------------------------------------------------------------------

async def handle_status(request: web.Request) -> web.Response:
    client: DoordeerClient = request.app["client"]
    return web.json_response({
        "connected": client.connected,
        "token_present": client.token is not None,
        "rtsp_main": client.rtsp_main_url,
        "rtsp_sub": client.rtsp_sub_url,
        "video_format": client.rtsp_video_format,
        "audio_format": client.rtsp_audio_format,
        "server_time": time.time(),
    })


async def handle_unlock(request: web.Request) -> web.Response:
    client: DoordeerClient = request.app["client"]
    success = await client.unlock()
    return web.json_response({"success": success}, status=200 if success else 502)


async def handle_snapshot(request: web.Request) -> web.Response:
    client: DoordeerClient = request.app["client"]
    data = await client.get_snapshot()
    if data is None:
        return web.Response(status=502, text="Failed to get snapshot from device")
    return web.Response(body=data, content_type="image/jpeg")


async def handle_rtsp(request: web.Request) -> web.Response:
    client: DoordeerClient = request.app["client"]
    info = await client.get_rtsp_info()
    if info is None:
        return web.json_response({"error": "Failed to get RTSP info"}, status=502)
    return web.json_response(info)


async def handle_change_password(request: web.Request) -> web.Response:
    client: DoordeerClient = request.app["client"]
    try:
        body = await request.json()
        new_password = body.get("password", "")
        username = body.get("username", None)
        if not new_password:
            return web.json_response({"error": "password required"}, status=400)
        success = await client.change_password(new_password, username)
        return web.json_response({"success": success})
    except Exception as exc:
        return web.json_response({"error": str(exc)}, status=400)


async def handle_access_log(request: web.Request) -> web.Response:
    client: DoordeerClient = request.app["client"]
    limit = int(request.query.get("limit", 100))
    return web.json_response({"log": client.get_access_log(limit=limit)})


async def handle_log_event(request: web.Request) -> web.Response:
    """External event injection — e.g. doorbell press from physical button webhook."""
    client: DoordeerClient = request.app["client"]
    try:
        body = await request.json()
        client.log_external_event(
            event=body.get("event", "external_event"),
            source=body.get("source", "webhook"),
            detail=body.get("detail", ""),
        )
        return web.json_response({"success": True})
    except Exception as exc:
        return web.json_response({"error": str(exc)}, status=400)


async def handle_index(request: web.Request) -> web.FileResponse:
    """Serve the ingress panel UI."""
    return web.FileResponse(Path(__file__).parent.parent / "www" / "index.html")


# ---------------------------------------------------------------------------
# Background tasks
# ---------------------------------------------------------------------------

async def token_refresh_task(app: web.Application) -> None:
    client: DoordeerClient = app["client"]
    interval = int(os.environ.get("TOKEN_REFRESH", 540))
    while True:
        await asyncio.sleep(interval)
        _LOGGER.info("Doordeer: scheduled token refresh")
        await client._login()


async def snapshot_task(app: web.Application) -> None:
    """Periodically store latest snapshot in memory for fast serving."""
    client: DoordeerClient = app["client"]
    interval = int(os.environ.get("SNAPSHOT_INTERVAL", 10))
    while True:
        await asyncio.sleep(interval)
        data = await client.get_snapshot()
        if data:
            app["latest_snapshot"] = data


async def log_prune_task(app: web.Application) -> None:
    client: DoordeerClient = app["client"]
    retention = int(os.environ.get("LOG_RETENTION", 30))
    while True:
        await asyncio.sleep(3600)
        client.prune_log(max_age_days=retention)
        _LOGGER.info("Doordeer: access log pruned (retention=%d days)", retention)


async def rtsp_init_task(app: web.Application) -> None:
    """Fetch RTSP info once at startup and cache it."""
    await asyncio.sleep(2)
    client: DoordeerClient = app["client"]
    await client.get_rtsp_info()


# ---------------------------------------------------------------------------
# App lifecycle
# ---------------------------------------------------------------------------

async def on_startup(app: web.Application) -> None:
    config = get_config()
    client = DoordeerClient(config)
    await client.start()
    app["client"] = client
    app["latest_snapshot"] = None

    app["tasks"] = [
        asyncio.create_task(token_refresh_task(app)),
        asyncio.create_task(snapshot_task(app)),
        asyncio.create_task(log_prune_task(app)),
        asyncio.create_task(rtsp_init_task(app)),
    ]
    _LOGGER.info("Doordeer addon started — device: %s:%s", config.device_ip, config.device_port)


async def on_cleanup(app: web.Application) -> None:
    for task in app.get("tasks", []):
        task.cancel()
    client: DoordeerClient = app.get("client")
    if client:
        await client.stop()
    _LOGGER.info("Doordeer addon stopped")


async def handle_cached_snapshot(request: web.Request) -> web.Response:
    """Return the most recently cached snapshot (fast, no device round-trip)."""
    data = request.app.get("latest_snapshot")
    if data is None:
        # Fall back to live fetch
        return await handle_snapshot(request)
    return web.Response(body=data, content_type="image/jpeg")


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

def create_app() -> web.Application:
    app = web.Application()
    app.on_startup.append(on_startup)
    app.on_cleanup.append(on_cleanup)

    app.router.add_get("/", handle_index)
    app.router.add_get("/api/status", handle_status)
    app.router.add_post("/api/unlock", handle_unlock)
    app.router.add_get("/api/snapshot", handle_cached_snapshot)
    app.router.add_get("/api/snapshot/live", handle_snapshot)
    app.router.add_get("/api/rtsp", handle_rtsp)
    app.router.add_post("/api/password", handle_change_password)
    app.router.add_get("/api/log", handle_access_log)
    app.router.add_post("/api/log/event", handle_log_event)

    # Static files for panel UI
    www_path = Path(__file__).parent.parent / "www"
    if www_path.exists():
        app.router.add_static("/static", www_path)

    return app


def main() -> None:
    app = create_app()
    web.run_app(app, host="0.0.0.0", port=8099)


if __name__ == "__main__":
    main()
