"""Doordeer Smart Intercom — LAN API integration addon."""
