"""
RC4 encryption + Base64 encoding as required by the doordeer LAN API.
All payloads must be RC4-encrypted with the vendor key, then base64-encoded.
"""
import base64
import json
import os
from typing import Any


def rc4_encrypt(key: str, data: str) -> bytes:
    """RC4 stream cipher encrypt/decrypt (symmetric)."""
    key_bytes = key.encode("utf-8")
    data_bytes = data.encode("utf-8")

    # Key-scheduling algorithm (KSA)
    S = list(range(256))
    j = 0
    for i in range(256):
        j = (j + S[i] + key_bytes[i % len(key_bytes)]) % 256
        S[i], S[j] = S[j], S[i]

    # Pseudo-random generation algorithm (PRGA)
    i = j = 0
    result = []
    for byte in data_bytes:
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        result.append(byte ^ S[(S[i] + S[j]) % 256])

    return bytes(result)


def encode_payload(key: str, payload: dict[str, Any]) -> str:
    """
    Encode a dict payload for the doordeer API:
      1. JSON-serialize
      2. RC4-encrypt with vendor key
      3. Base64-encode
    Returns the stringdata value for {"jsondata": "<stringdata>"}
    """
    json_str = json.dumps(payload, separators=(",", ":"))
    rc4_bytes = rc4_encrypt(key, json_str)
    return base64.b64encode(rc4_bytes).decode("utf-8")


def build_request_body(key: str, payload: dict[str, Any]) -> dict[str, str]:
    """Return the full {"jsondata": "..."} body ready to POST."""
    return {"jsondata": encode_payload(key, payload)}
