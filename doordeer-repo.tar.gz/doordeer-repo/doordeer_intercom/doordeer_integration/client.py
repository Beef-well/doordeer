"""
doordeer LAN API Client
Handles authentication (token lifecycle), unlock, snapshots, RTSP, and settings.
"""
import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Optional

import aiohttp

from .crypto import build_request_body

_LOGGER = logging.getLogger(__name__)

TOKEN_LIFETIME = 600          # 10 minutes per API spec
TOKEN_REFRESH_BEFORE = 60     # refresh 60 s before expiry


@dataclass
class DoordeerConfig:
    device_ip: str
    device_port: int
    username: str
    password: str
    rc4_key: str

    @property
    def base_url(self) -> str:
        return f"http://{self.device_ip}:{self.device_port}"


@dataclass
class AccessLogEntry:
    timestamp: float
    event: str
    source: str
    detail: str = ""

    def to_dict(self) -> dict:
        return {
            "timestamp": self.timestamp,
            "event": self.event,
            "source": self.source,
            "detail": self.detail,
        }


class DoordeerClient:
    """Async LAN API client for doordeer intercom devices."""

    def __init__(self, config: DoordeerConfig):
        self._config = config
        self._token: Optional[str] = None
        self._token_acquired: float = 0.0
        self._session: Optional[aiohttp.ClientSession] = None
        self._lock = asyncio.Lock()
        self._access_log: list[AccessLogEntry] = []
        self._rtsp_info: Optional[dict] = None
        self._connected: bool = False

    # ------------------------------------------------------------------ #
    #  Session management                                                  #
    # ------------------------------------------------------------------ #

    async def start(self) -> None:
        self._session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=10)
        )
        await self._login()

    async def stop(self) -> None:
        if self._session:
            await self._session.close()
            self._session = None

    # ------------------------------------------------------------------ #
    #  Authentication                                                      #
    # ------------------------------------------------------------------ #

    async def _login(self) -> bool:
        """Login and store token. Returns True on success."""
        payload = {
            "function": "login",
            "user": self._config.username,
            "password": self._config.password,
        }
        body = build_request_body(self._config.rc4_key, payload)
        try:
            async with self._session.post(
                f"{self._config.base_url}/login",
                json=body,
                headers={"Content-Type": "application/json"},
            ) as resp:
                data = await resp.json(content_type=None)
                if data.get("rescode") == "200":
                    self._token = data["token"]
                    self._token_acquired = time.monotonic()
                    self._connected = True
                    _LOGGER.info("Doordeer: login successful, token acquired")
                    self._log_event("auth", "addon", "Login successful")
                    return True
                _LOGGER.error("Doordeer: login failed: %s", data)
                self._connected = False
                return False
        except Exception as exc:
            _LOGGER.error("Doordeer: login exception: %s", exc)
            self._connected = False
            return False

    async def _ensure_token(self) -> bool:
        """Refresh token if it is close to expiry."""
        async with self._lock:
            age = time.monotonic() - self._token_acquired
            if self._token is None or age >= (TOKEN_LIFETIME - TOKEN_REFRESH_BEFORE):
                _LOGGER.debug("Doordeer: token refresh needed (age=%.0fs)", age)
                return await self._login()
        return True

    @property
    def token(self) -> Optional[str]:
        return self._token

    @property
    def connected(self) -> bool:
        return self._connected

    # ------------------------------------------------------------------ #
    #  Door unlock                                                         #
    # ------------------------------------------------------------------ #

    async def unlock(self) -> bool:
        """Send unlock command. Returns True on success."""
        if not await self._ensure_token():
            return False
        try:
            async with self._session.post(
                f"{self._config.base_url}/openlock",
                params={"token": self._token},
                headers={"Content-Type": "application/json"},
            ) as resp:
                data = await resp.json(content_type=None)
                success = data.get("rescode") == "200"
                event = "unlock_success" if success else "unlock_failed"
                self._log_event(event, "api", str(data))
                if success:
                    _LOGGER.info("Doordeer: door unlocked")
                else:
                    _LOGGER.warning("Doordeer: unlock failed: %s", data)
                return success
        except Exception as exc:
            _LOGGER.error("Doordeer: unlock exception: %s", exc)
            self._log_event("unlock_error", "api", str(exc))
            return False

    # ------------------------------------------------------------------ #
    #  Password / keycode management                                       #
    # ------------------------------------------------------------------ #

    async def change_password(self, new_password: str, username: Optional[str] = None) -> bool:
        """Change the device login password."""
        if not await self._ensure_token():
            return False
        payload = {
            "function": "setuserpassword",
            "user": username or self._config.username,
            "password": new_password,
        }
        body = build_request_body(self._config.rc4_key, payload)
        try:
            async with self._session.post(
                f"{self._config.base_url}/setting",
                params={"token": self._token},
                json=body,
                headers={"Content-Type": "application/json"},
            ) as resp:
                data = await resp.json(content_type=None)
                success = data.get("rescode") == "200"
                self._log_event(
                    "password_changed" if success else "password_change_failed",
                    "api",
                    f"user={username or self._config.username}",
                )
                return success
        except Exception as exc:
            _LOGGER.error("Doordeer: change_password exception: %s", exc)
            return False

    # ------------------------------------------------------------------ #
    #  Camera: snapshot                                                    #
    # ------------------------------------------------------------------ #

    async def get_snapshot(self) -> Optional[bytes]:
        """Fetch a JPEG snapshot from the device. Returns raw bytes."""
        if not await self._ensure_token():
            return None
        try:
            async with self._session.post(
                f"{self._config.base_url}/getpic",
                params={"token": self._token},
                headers={"Content-Type": "image/jpeg"},
            ) as resp:
                if resp.status == 200:
                    return await resp.read()
                _LOGGER.warning("Doordeer: snapshot returned %s", resp.status)
                return None
        except Exception as exc:
            _LOGGER.error("Doordeer: get_snapshot exception: %s", exc)
            return None

    # ------------------------------------------------------------------ #
    #  Camera: RTSP info                                                   #
    # ------------------------------------------------------------------ #

    async def get_rtsp_info(self) -> Optional[dict]:
        """Fetch RTSP stream URLs and codec info."""
        if not await self._ensure_token():
            return None
        try:
            async with self._session.post(
                f"{self._config.base_url}/getrtsp",
                params={"token": self._token},
                headers={"Content-Type": "application/json"},
            ) as resp:
                data = await resp.json(content_type=None)
                self._rtsp_info = data
                _LOGGER.info("Doordeer RTSP info: %s", data)
                return data
        except Exception as exc:
            _LOGGER.error("Doordeer: get_rtsp_info exception: %s", exc)
            return None

    @property
    def rtsp_main_url(self) -> Optional[str]:
        return self._rtsp_info.get("mainvideo") if self._rtsp_info else None

    @property
    def rtsp_sub_url(self) -> Optional[str]:
        return self._rtsp_info.get("subvideo") if self._rtsp_info else None

    @property
    def rtsp_video_format(self) -> Optional[str]:
        return self._rtsp_info.get("videoformat") if self._rtsp_info else None

    @property
    def rtsp_audio_format(self) -> Optional[str]:
        return self._rtsp_info.get("audioformat") if self._rtsp_info else None

    # ------------------------------------------------------------------ #
    #  Access log                                                          #
    # ------------------------------------------------------------------ #

    def _log_event(self, event: str, source: str, detail: str = "") -> None:
        entry = AccessLogEntry(
            timestamp=time.time(),
            event=event,
            source=source,
            detail=detail,
        )
        self._access_log.append(entry)
        _LOGGER.debug("Doordeer log: %s", entry)

    def get_access_log(self, limit: int = 100) -> list[dict]:
        return [e.to_dict() for e in reversed(self._access_log[-limit:])]

    def prune_log(self, max_age_days: int = 30) -> None:
        cutoff = time.time() - (max_age_days * 86400)
        self._access_log = [e for e in self._access_log if e.timestamp >= cutoff]

    def log_external_event(self, event: str, source: str = "external", detail: str = "") -> None:
        """Allow the webhook/event system to inject events (e.g. doorbell press)."""
        self._log_event(event, source, detail)
