#!/usr/bin/with-contenv bashio

declare DEVICE_IP
declare DEVICE_PORT
declare USERNAME
declare PASSWORD
declare RC4_KEY
declare TOKEN_REFRESH
declare SNAPSHOT_INTERVAL
declare RTSP_STREAM
declare LOG_RETENTION

DEVICE_IP=$(bashio::config 'device_ip')
DEVICE_PORT=$(bashio::config 'device_port')
USERNAME=$(bashio::config 'username')
PASSWORD=$(bashio::config 'password')
RC4_KEY=$(bashio::config 'rc4_key')
TOKEN_REFRESH=$(bashio::config 'token_refresh_interval')
SNAPSHOT_INTERVAL=$(bashio::config 'snapshot_interval')
RTSP_STREAM=$(bashio::config 'rtsp_stream')
LOG_RETENTION=$(bashio::config 'log_retention_days')

export DEVICE_IP DEVICE_PORT USERNAME PASSWORD RC4_KEY
export TOKEN_REFRESH SNAPSHOT_INTERVAL RTSP_STREAM LOG_RETENTION

bashio::log.info "Starting Doordeer Smart Intercom..."
bashio::log.info "Device: ${DEVICE_IP}:${DEVICE_PORT}"

if bashio::config.is_empty 'device_ip'; then
    bashio::log.fatal "device_ip is not configured. Set it in the addon configuration."
    exit 1
fi

if bashio::config.is_empty 'rc4_key'; then
    bashio::log.warning "rc4_key is not set. Login encryption will fail. Email doordeer for your key."
fi

cd /app
exec python3 -m doordeer_integration.main
